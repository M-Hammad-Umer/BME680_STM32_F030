/*
 * bme680_config.h
 *
 *  Created on: Jul 23, 2024
 *      Author: Zi
 */

#ifndef BME680_DRIVER_BME680_CONFIG_H_
#define BME680_DRIVER_BME680_CONFIG_H_

#include <drv_bme680.h>

#define BME680_MANF_CHIP_ID							 0x61U

#define BME680_HUMID_OVER_SAMPLING_CONFIG			 humid_over_sampling_x1
#define BME680_TEMP_OVER_SAMPLING_CONFIG			 temp_over_sampling_x2
#define BME680_PRESS_OVER_SAMPLING_CONFIG			 press_over_sampling_x16

#define BME680_IIR_FILTER_RESOLUTION_CONFIG			 iir_filter_coffi_0


#endif /* BME680_DRIVER_BME680_CONFIG_H_ */
