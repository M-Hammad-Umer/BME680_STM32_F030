/*
 * drv_bme640.h
 *
 *  Created on: Jul 20, 2024
 *      Author: Muhammad Hammad Umer
 */

#ifndef BME680_DRIVER_DRV_BME680_H_
#define BME680_DRIVER_DRV_BME680_H_


#include <stdio.h>
#include <stdint.h>
#include "main.h"

/* COMMUNICATION_PROTOCOL_HANDLER_START */

extern I2C_HandleTypeDef hi2c2;
#define BME680_I2C_HANDLER	hi2c2

/* COMMUNICATION_PROTOCOL_HANDLER_END */


/* DEVICE_ADDRESS_START */

#define BME680_DEVICE_ADDRESS_GND	0x76U
#define BME680_DEVICE_ADDRESS_Vdd	0x77U

/* DEVICE_ADDRESS_END */


/* REGISTER_ADDRESS_START */

#define BME680_TEMP_CALLI_FACTOR_PAR_T1_MSB_REGISTER		0xEAU
#define BME680_TEMP_CALLI_FACTOR_PAR_T1_LSB_REGISTER		0xE9U
#define BME680_TEMP_CALLI_FACTOR_PAR_T2_MSB_REGISTER		0x8BU
#define BME680_TEMP_CALLI_FACTOR_PAR_T2_LSB_REGISTER		0x8AU
#define BME680_TEMP_CALLI_FACTOR_PAR_T3_REGISTER			0x8CU
#define BME680_TEMP_ADC_MSB_REGISTER						0x22U
#define BME680_TEMP_ADC_LSB_REGISTER						0x23U
#define BME680_TEMP_ADC_XLSB_REGISTER						0x24U	/* Not all the bits of this register are used, No of bit depends
														   	   	   	   upon Enabling and Disabling IIR Filter see section 3.3.1 */

#define BME680_PRESS_CALLI_FACTOR_PAR_P1_MSB_REGISTER		0x8FU
#define BME680_PRESS_CALLI_FACTOR_PAR_P1_LSB_REGISTER		0x8EU
#define BME680_PRESS_CALLI_FACTOR_PAR_P2_MSB_REGISTER		0x91U
#define BME680_PRESS_CALLI_FACTOR_PAR_P2_LSB_REGISTER		0x90U
#define BME680_PRESS_CALLI_FACTOR_PAR_P3_REGISTER			0x92U
#define BME680_PRESS_CALLI_FACTOR_PAR_P4_MSB_REGISTER		0x95U
#define BME680_PRESS_CALLI_FACTOR_PAR_P4_LSB_REGISTER		0x94U
#define BME680_PRESS_CALLI_FACTOR_PAR_P5_MSB_REGISTER		0x97U
#define BME680_PRESS_CALLI_FACTOR_PAR_P5_LSB_REGISTER		0x96U
#define BME680_PRESS_CALLI_FACTOR_PAR_P6_REGISTER			0x99U
#define BME680_PRESS_CALLI_FACTOR_PAR_P7_REGISTER			0x98U
#define BME680_PRESS_CALLI_FACTOR_PAR_P8_MSB_REGISTER		0x9DU
#define BME680_PRESS_CALLI_FACTOR_PAR_P8_LSB_REGISTER		0x9CU
#define BME680_PRESS_CALLI_FACTOR_PAR_P9_MSB_REGISTER		0x9FU
#define BME680_PRESS_CALLI_FACTOR_PAR_P9_LSB_REGISTER		0x9EU
#define BME680_PRESS_CALLI_FACTOR_PAR_P10_REGISTER			0xA0U
#define BME680_PRESS_ADC_MSB_REGISTER						0x1FU
#define BME680_PRESS_ADC_LSB_REGISTER						0x20U
#define BME680_PRESS_ADC_XLSB_REGISTER						0x21U


#define BME680_HUMID_CALLI_FACTOR_PAR_H1_MSB_REGISTER		0xE3U
#define BME680_HUMID_CALLI_FACTOR_PAR_H1_H2_LSB_REGISTER	0xE2U
#define BME680_HUMID_CALLI_FACTOR_PAR_H2_MSB_REGISTER		0xE1U
#define BME680_HUMID_CALLI_FACTOR_PAR_H3_REGISTER			0xE4U
#define BME680_HUMID_CALLI_FACTOR_PAR_H4_REGISTER			0xE5U
#define BME680_HUMID_CALLI_FACTOR_PAR_H5_REGISTER			0xE6U
#define BME680_HUMID_CALLI_FACTOR_PAR_H6_REGISTER			0xE7U
#define BME680_HUMID_CALLI_FACTOR_PAR_H7_REGISTER			0xE8U
#define BME680_HUMID_ADC_MSB_REGISTER						0x25U
#define BME680_HUMID_ADC_LSB_REGISTER						0x26U


#define BME680_HEATER_CALLI_FACTOR_PAR_G1_REGISTER			0xEDU
#define BME680_HEATER_CALLI_FACTOR_PAR_G2_MSB_REGISTER		0xECU
#define BME680_HEATER_CALLI_FACTOR_PAR_G2_LSB_REGISTER		0xEBU
#define BME680_HEATER_CALLI_FACTOR_PAR_G3_REGISTER			0xEEU
#define BME680_HEATER_RES_HEAT_RANGE_REGISTER				0x02U
#define BME680_HEATER_RES_HEAT_VAL_REGISTER					0x00U


#define BME680_GAS_SENSOR_TARGET_HEATER_RESIST_0_REGISTER	0x5aU
#define BME680_GAS_SENSOR_TARGET_HEATER_RESIST_1_REGISTER	0x5bU
#define BME680_GAS_SENSOR_TARGET_HEATER_RESIST_2_REGISTER	0x5cU
#define BME680_GAS_SENSOR_TARGET_HEATER_RESIST_3_REGISTER	0x5dU
#define BME680_GAS_SENSOR_TARGET_HEATER_RESIST_4_REGISTER	0x5eU
#define BME680_GAS_SENSOR_TARGET_HEATER_RESIST_5_REGISTER	0x5fU
#define BME680_GAS_SENSOR_TARGET_HEATER_RESIST_6_REGISTER	0x60U
#define BME680_GAS_SENSOR_TARGET_HEATER_RESIST_7_REGISTER	0x61U
#define BME680_GAS_SENSOR_TARGET_HEATER_RESIST_8_REGISTER	0x62U
#define BME680_GAS_SENSOR_TARGET_HEATER_RESIST_9_REGISTER	0x63U


#define BME680_GAS_SENSOR_WAIT_TIME_0_REGISTER				0x64U
#define BME680_GAS_SENSOR_WAIT_TIME_1_REGISTER				0x65U
#define BME680_GAS_SENSOR_WAIT_TIME_2_REGISTER				0x66U
#define BME680_GAS_SENSOR_WAIT_TIME_3_REGISTER				0x67U
#define BME680_GAS_SENSOR_WAIT_TIME_4_REGISTER				0x68U
#define BME680_GAS_SENSOR_WAIT_TIME_5_REGISTER				0x69U
#define BME680_GAS_SENSOR_WAIT_TIME_6_REGISTER				0x6aU
#define BME680_GAS_SENSOR_WAIT_TIME_7_REGISTER				0x6bU
#define BME680_GAS_SENSOR_WAIT_TIME_8_REGISTER				0x6cU
#define BME680_GAS_SENSOR_WAIT_TIME_9_REGISTER				0x6dU

#define BME680_GAS_RANGE_SWITCHING_ERROR_REGISTER			0x04U

#define BME680_GAS_R_MSB_REGISTER							0x2AU
#define BME680_GAS_R_LSB_REGISTER							0x2BU

#define BME680_CRTL_GAS_0_REGISTER							0x70U
#define BME680_CRTL_GAS_1_REGISTER							0x71U
#define BME680_CTRL_HUM_REGISTER							0x72U
#define BME680_CTRL_MEAS_REGISTER							0x74U
#define BME680_IIR_FLITER_CONTROL_REGISTER					0x75U

#define BME680_MEASUREMENT_STATUS_REGISTER					0X1DU

#define BME680_CHIP_ID_REGISTER								0xD0U
#define BME680_SOFT_RESET_REGISTER							0xE0U

/* REGISTER_ADDRESS_END */

/*  USER_DEFINED_DATATYPES_START  */


/*  USER_DEFINED_DATATYPES_END  */

typedef struct
{
	 float temp;
	 float press;
	 float humid;
	 float heater_resistance;
	 float iaq;
}bme680_output_t;

/*  ENUMS_START  */

typedef enum
{
	/* filter <2:0> */
	iir_filter_coffi_0   = 0b00000000,
	iir_filter_coffi_1   = 0b00000100,
	iir_filter_coffi_3   = 0b00001000,
	iir_filter_coffi_7   = 0b00001100,
	iir_filter_coffi_15  = 0b00010000,
	iir_filter_coffi_31  = 0b00010100,
	iir_filter_coffi_63  = 0b00011000,
	iir_filter_coffi_127 = 0b00011100
	/* Add more according to datasheet if required */

}bme860_iir_filter_settings_t;

typedef enum
{
	/* mode <1:0> */
	sleep_mode   = 0b00000000,	/* No measurement | Minimal Power Consumption */
	forced_mode  = 0b00000001,  /* Single TPHG measurement | Sensor automatically return to sleep mode after measurement |
	 	 	 	 	 	 	 	   Gas sensor heater only operates during gas measurement	 */
}bme680_operational_modes_t;

typedef enum
{
	/* osrs_t <7:5> */
	temp_over_sampling_skipped 	= 0b00000000,
	temp_over_sampling_x1 		= 0b00100000,
	temp_over_sampling_x2	 	= 0b01000000,
	temp_over_sampling_x4 		= 0b01100000,
	temp_over_sampling_x8 		= 0b10000000,
	temp_over_sampling_x16 		= 0b10100000,

}bme680_temp_over_sampling_macros;

typedef enum
{
	/* osrs_p <4:2> */
	press_over_sampling_skipped = 0b00000000,
	press_over_sampling_x1 		= 0b00000100,
	press_over_sampling_x2	 	= 0b00001000,
	press_over_sampling_x4 		= 0b00001100,
	press_over_sampling_x8 		= 0b00010000,
	press_over_sampling_x16 	= 0b00010100

}bme680_press_over_sampling_macros;

typedef enum
{
	/* osrs_h <2:0> */
	humid_over_sampling_skipped = 0b00000000,
	humid_over_sampling_x1 		= 0b00000001,
	humid_over_sampling_x2	 	= 0b00000010,
	humid_over_sampling_x4 		= 0b00000011,
	humid_over_sampling_x8 		= 0b00000100,
	humid_over_sampling_x16 	= 0b00000101

}bme680_humid_over_sampling_macros;

typedef enum
{
	gas_ctrl_1_run_gas 			= 0b00010000,

	gas_ctrl_1_heat_set_point_0 = 0b00000000,
	gas_ctrl_1_heat_set_point_1 = 0b00000001,
	gas_ctrl_1_heat_set_point_2 = 0b00000010,
	gas_ctrl_1_heat_set_point_3 = 0b00000011,
	gas_ctrl_1_heat_set_point_4 = 0b00000100,
	gas_ctrl_1_heat_set_point_5 = 0b00000101,
	gas_ctrl_1_heat_set_point_6 = 0b00000110,
	gas_ctrl_1_heat_set_point_7 = 0b00000111,
	gas_ctrl_1_heat_set_point_8 = 0b00001000,
	gas_ctrl_1_heat_set_point_9 = 0b00001001,

	gas_ctrl_0_heat_on			= 0b00000000,
	gas_ctrl_0_heat_off			= 0b00001000,

}bme680_gas_ctrl_0_1_run_gas_macros;

/*  ENUMS_END  */

/* PRIVATE_FUNCTIONS_START */

/**
 *  drv_bme680_write_register can write max of 4 bytes at a time to a single register, edit the function to increase
 */

static HAL_StatusTypeDef drv_bme680_set_iir_filter_config(bme860_iir_filter_settings_t bme860_iir_filter_settings);

static HAL_StatusTypeDef drv_bme680_get_temp_calli_factors();
static HAL_StatusTypeDef drv_bme680_get_press_calli_factors();
static HAL_StatusTypeDef drv_bme680_get_humid_calli_factors();
static HAL_StatusTypeDef drv_bme680_get_heater_and_gas_calli_factors();
static HAL_StatusTypeDef drv_bme680_set_gas_wait_profile(uint8_t* gas_wait, uint8_t no_of_profile);
static HAL_StatusTypeDef drv_bme680_set_heater_resistance_profile(uint16_t* temp_for_resistance, uint8_t no_of_profile);

static HAL_StatusTypeDef drv_bme680_read_temp_adc(uint32_t* temp_adc);
static HAL_StatusTypeDef drv_bme680_read_press_adc(uint32_t* press_adc);
static HAL_StatusTypeDef drv_bme680_read_humid_adc(uint16_t* humid_adc);
static HAL_StatusTypeDef drv_bme680_read_gas_adc(uint16_t* gas_adc);

static HAL_StatusTypeDef drv_bme680_measuremen_complete_check();
static HAL_StatusTypeDef drv_bme680_set_op_mode(bme680_operational_modes_t op_mode);

static float drv_bme380_int_temp_algo(uint32_t temp_adc);
static float drv_bme380_int_press_algo(uint32_t press_adc);
static float drv_bme380_int_humid_algo(uint16_t humid_adc);
static float drv_bme380_int_gas_resistance_algo(uint16_t gas_adc);
static uint8_t calc_res_heat(uint16_t temp);
static uint8_t calc_gas_wait(uint16_t dur);

static HAL_StatusTypeDef drv_bme680_write_register(uint8_t reg_add, uint8_t* pdata, uint16_t size_to_write, uint32_t timeout);
static HAL_StatusTypeDef drv_bme680_read_register(uint8_t reg_add, uint8_t* pdata, uint16_t size_to_read, uint32_t timeout);
static void drv_bme680_delay_us(uint32_t delay_us);
static uint32_t drv_bme680_calculate_delay_for_TPGH_cycle();

static void drv_bme680_get_gas_reference();
static int8_t drv_bme680_get_humidity_score(float humid);
static int8_t drv_bme680_get_gas_score();
float drv_bme680_iaq(bme680_output_t* data);




/* PRIVATE_FUNCTIONS_END */

/* PUBLIC_FUNCTIONS_START */

HAL_StatusTypeDef drv_bme680_read_all_data(bme680_output_t* data);


HAL_StatusTypeDef drv_bme680_get_dev_id(uint8_t* dev_id); 	//ap_com_check();

HAL_StatusTypeDef drv_bme680_soft_reset();

static HAL_StatusTypeDef drv_bme680_get_temp(float* temp);

static HAL_StatusTypeDef drv_bme680_get_press(float* press);

static HAL_StatusTypeDef drv_bme680_get_humid(float* humid);

static HAL_StatusTypeDef drv_bme680_get_resistance(float* resistance);


/* PUBLIC_FUNCTIONS_END */


#endif /* BME680_DRIVER_DRV_BME680_H_ */
