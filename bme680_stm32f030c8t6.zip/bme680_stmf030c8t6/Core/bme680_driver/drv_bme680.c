/*
 * drv_bme640.c
 *
 *  Created on: Jul 20, 2024
 *      Author: Muhammad Hammad Umer
 */
#include "main.h"
#include "drv_bme680.h"
#include "bme680_config.h"

typedef struct {
 	uint16_t par_t1;
 	uint16_t par_t2;
 	uint8_t par_t3;
 	float t_fine;
 	uint8_t temp_oversampling_settings;				// This variable is used to hold the temperature over sampling settings

 	uint16_t par_p1;
 	uint16_t par_p2;
 	uint8_t par_p3;
 	uint16_t par_p4;
 	uint16_t par_p5;
 	uint8_t par_p6;
 	uint8_t par_p7;
 	uint16_t par_p8;
 	uint16_t par_p9;
 	uint8_t par_p10;
 	uint8_t press_oversampling_settings;				// This variable is used to hold the presssure over sampling settings

 	uint16_t par_h1;
 	uint16_t par_h2;
 	uint8_t par_h3;
 	uint8_t par_h4;
 	uint8_t par_h5;
 	uint8_t par_h6;
 	uint8_t par_h7;
 	uint8_t humid_oversampling_settings;				// This variable is used to hold the presssure over sampling settings

 	uint8_t par_g1;
 	uint16_t par_g2;
 	uint8_t par_g3;
 	uint8_t res_heat_range;
 	uint8_t res_heat_val;

 	uint8_t gas_range;
 	uint8_t range_switching_error;

	uint8_t all_adc_reg_data[15];
 	bme860_iir_filter_settings_t iir_filter_reso;
 	int8_t amb_temp;
 	uint8_t heater_set_point_index;

 	bool new_data_0_flag;
 	bool gas_measuring_flag;
 	bool measuring_flag;
 	bool gas_valid_r_flag;
 	bool heat_stab_r_flag;


}bme680_param_holder_t;


//bme680_output_t global_data = {0};

// IAQ Calculation Variables
float humidity_score, gas_score;
float gas_reference = 250000;
float hum_reference = 40;
int8_t getgasreference_count = 0;
float gas_lower_limit = 5000;   // Bad air quality limit
float gas_upper_limit = 50000;  // Good air quality limit

/* GLOBAL_VARIABLES_START */

static bme680_param_holder_t bme680_param_holder = {0};

/* Heater temperature in degree Celcius */
static uint16_t heater_temp_prof[10U] = { 320U, 320U, 320U, 320U, 320U, 320U, 320U, 320U, 320U, 320U };

/* Heating duration in milliseconds */
static uint8_t heater_duration_profile[10] = { 150U, 150U, 150U, 150U, 150U, 150U, 150U, 150U, 150U, 150U };

/* GLOBAL_VARIABLES_START */

/*								PUBLIC FUNCTION DEFINITIONS	START							*/

HAL_StatusTypeDef drv_bme680_init()
{
     HAL_StatusTypeDef status = HAL_ERROR;

     uint8_t dev_id = 0x00;

     status = drv_bme680_get_dev_id(&dev_id);

     bme680_param_holder.amb_temp = 25U;

     if(status == HAL_OK)
     {
    	 if(dev_id != BME680_MANF_CHIP_ID)
    	 {
    		 /* TODO: Generate warning on LOGs */
    	 }

    	 status = drv_bme680_soft_reset();

    	 /* Getting configurations from bme680_config.h*/
    	 bme680_param_holder.temp_oversampling_settings  = (BME680_TEMP_OVER_SAMPLING_CONFIG >> 5U);
    	 bme680_param_holder.press_oversampling_settings = (BME680_PRESS_OVER_SAMPLING_CONFIG >> 2U);
    	 bme680_param_holder.humid_oversampling_settings = BME680_HUMID_OVER_SAMPLING_CONFIG;
    	 bme680_param_holder.iir_filter_reso			 = BME680_IIR_FILTER_RESOLUTION_CONFIG;
    	 bme680_param_holder.heater_set_point_index		 = gas_ctrl_1_heat_set_point_0;

		 /*
		  * Set humidity over sampling to 1x by writing 0b001 to osrs_h<2:0>
		  * Set temperature over sampling to 2x by writing 0b010 to osrs_t<2:0>
		  * Set pressure over sampling to 16x by writing 0b101 to osrs_p<2:0>
		  * It is recommended in data sheet to write these 3 registers in one cycle and in the following sequence
		  */
    	 status = drv_bme680_set_op_mode(sleep_mode);

       	 status = drv_bme680_get_temp_calli_factors();

         status = drv_bme680_get_press_calli_factors();

         status = drv_bme680_get_humid_calli_factors();

    	 status = drv_bme680_get_heater_and_gas_calli_factors();

    	 /* STEP 1: Select over sampling for T, P and H */
       	 uint8_t crtl_meas_reg = BME680_TEMP_OVER_SAMPLING_CONFIG | BME680_PRESS_OVER_SAMPLING_CONFIG;

         uint8_t tph_over_smapling_buff[4U] = {BME680_CTRL_HUM_REGISTER, BME680_HUMID_OVER_SAMPLING_CONFIG, BME680_CTRL_MEAS_REGISTER, crtl_meas_reg };

    	 status = HAL_I2C_Master_Transmit(&BME680_I2C_HANDLER, (BME680_DEVICE_ADDRESS_GND << 1U), tph_over_smapling_buff, 4U, 100U);

    	 /* STEP 2: Select IIR filter for temperature sensor */
    	 status = drv_bme680_set_iir_filter_config(bme680_param_holder.iir_filter_reso);

    	 /* STEP 5: Define heater-on time */
    	 status = drv_bme680_set_gas_wait_profile(heater_duration_profile, 10U);

    	 /* STEP 6: Set heater temperature */
    	 status = drv_bme680_set_heater_resistance_profile(heater_temp_prof, 10U);

    	 /* STEP 3: Enable gas conversion
    	  * STEP 4: Select Index of heater set point */
    	 uint8_t ctrl_gas_1_reg = gas_ctrl_1_run_gas | bme680_param_holder.heater_set_point_index;
    	 uint8_t ctrl_gas_0_reg = gas_ctrl_0_heat_on;

    	 status = drv_bme680_write_register(BME680_CRTL_GAS_0_REGISTER, &ctrl_gas_0_reg, 1U, 200U);

    	 status = drv_bme680_write_register(BME680_CRTL_GAS_1_REGISTER, &ctrl_gas_1_reg, 1U, 200U);

    	 drv_bme680_get_gas_reference();
    }
    else
    {
		 /* TODO: Generate COM_FAILED_ERROR on LOGs */
    }

	return status;
}

static HAL_StatusTypeDef drv_bme680_set_op_mode(bme680_operational_modes_t op_mode)
{
	HAL_StatusTypeDef status = HAL_OK;

	uint8_t read_buffer = 0;

	status = drv_bme680_read_register(BME680_CTRL_MEAS_REGISTER, &read_buffer, 1, 100);

	if(status == HAL_OK)
	{
		read_buffer = (read_buffer | op_mode);

		status = drv_bme680_write_register(BME680_CTRL_MEAS_REGISTER, &read_buffer, 1, 100);
	}

	return status;
}

HAL_StatusTypeDef drv_bme680_read_all_data(bme680_output_t* data)
{
	HAL_StatusTypeDef status = HAL_OK;
	uint32_t delay_us = 0;

	 /* STEP 7: Set mode to forced mode to trigger the reading */
	status = drv_bme680_set_op_mode(forced_mode);

	delay_us = drv_bme680_calculate_delay_for_TPGH_cycle();	/* return delay in us*/

	drv_bme680_delay_us(delay_us);

	status = drv_bme680_read_register(BME680_MEASUREMENT_STATUS_REGISTER, bme680_param_holder.all_adc_reg_data, 15, 500);

	status = drv_bme680_measuremen_complete_check();

	if(status == HAL_OK)
	{
		status = drv_bme680_get_temp(&(data->temp));
		status = drv_bme680_get_press(&(data->press));
		status = drv_bme680_get_humid(&(data->humid));
		status = drv_bme680_get_resistance(&(data->heater_resistance));
	}

	return status;
}


static uint32_t drv_bme680_calculate_delay_for_TPGH_cycle()
{
	uint32_t total_delay_us = 0;
    uint32_t meas_cycles;
    uint8_t os_to_meas_cycles[6] = { 0, 1, 2, 4, 8, 16 };

    meas_cycles =  os_to_meas_cycles[bme680_param_holder.humid_oversampling_settings];
    meas_cycles += os_to_meas_cycles[bme680_param_holder.temp_oversampling_settings];
    meas_cycles += os_to_meas_cycles[bme680_param_holder.press_oversampling_settings];

    /* TPH measurement duration */
    total_delay_us = meas_cycles * UINT32_C(1963);
    total_delay_us += UINT32_C(477 * 4); /* TPH switching duration */
    total_delay_us += UINT32_C(477 * 5); /* Gas measurement duration */

    total_delay_us += UINT32_C(1000); /* Wake up duration of 1ms */

    total_delay_us += (heater_duration_profile[bme680_param_holder.heater_set_point_index] * 1000U);

    return total_delay_us;
}


HAL_StatusTypeDef drv_bme680_get_dev_id(uint8_t* dev_id)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	status = drv_bme680_read_register(BME680_CHIP_ID_REGISTER, dev_id, 1U, 100U);

	return status;
}

static HAL_StatusTypeDef drv_bme680_get_resistance(float* resistance)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	uint16_t gas_adc = 0U;

	status = drv_bme680_read_gas_adc(&gas_adc);

	if(status == HAL_OK)
	{
		*resistance = drv_bme380_int_gas_resistance_algo(gas_adc);
	}

	return status;
}


static HAL_StatusTypeDef drv_bme680_get_temp(float* temp)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	uint32_t temp_adc = 0U;

	status = drv_bme680_read_temp_adc(&temp_adc);

	if(status == HAL_OK && temp_adc != 0x800000U)
	{
		*temp = drv_bme380_int_temp_algo(temp_adc);
	}

	return status;
}


static HAL_StatusTypeDef drv_bme680_get_press(float* press)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	uint32_t press_adc = 0U;

	status = drv_bme680_read_press_adc(&press_adc);

	if(status == HAL_OK)
	{
		*press = drv_bme380_int_press_algo(press_adc);
	}

	return status;

}

static HAL_StatusTypeDef drv_bme680_get_humid(float* humid)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	uint16_t humid_adc = 0U;

	status = drv_bme680_read_humid_adc(&humid_adc);

	if(status == HAL_OK)
	{
		*humid = drv_bme380_int_humid_algo(humid_adc);
	}

	return status;

}


/*								PUBLIC_FUNCTION_DEFINITIONS_END							*/

/*								STATIC_FUNCTION_DEFINITIONS								*/

static HAL_StatusTypeDef drv_bme680_write_register(uint8_t reg_add, uint8_t* pdata, uint16_t size_to_write, uint32_t timeout)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	uint8_t send_buffer[5] = {reg_add, pdata[0], pdata[1], pdata[2], pdata[3]};

	status = HAL_I2C_Master_Transmit(&BME680_I2C_HANDLER, (BME680_DEVICE_ADDRESS_GND << 1U), send_buffer, (size_to_write+1U), timeout);

	return status;
}

static HAL_StatusTypeDef drv_bme680_read_register(uint8_t reg_add, uint8_t* pdata, uint16_t size_to_read, uint32_t timeout)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	status = HAL_I2C_Master_Transmit(&BME680_I2C_HANDLER, (BME680_DEVICE_ADDRESS_GND << 1U), &reg_add, 1U, timeout);

	if(status == HAL_OK)
	{
		status = HAL_I2C_Master_Receive(&BME680_I2C_HANDLER, (BME680_DEVICE_ADDRESS_GND << 1U), pdata, size_to_read, timeout);
	}

	return status;
}

static HAL_StatusTypeDef drv_bme680_get_temp_calli_factors()
{
	HAL_StatusTypeDef status = HAL_ERROR;

	uint8_t register_read_data[2U] = {0U};

	status = drv_bme680_read_register(BME680_TEMP_CALLI_FACTOR_PAR_T1_MSB_REGISTER, &register_read_data[0U], 1U, 500);

	status = drv_bme680_read_register(BME680_TEMP_CALLI_FACTOR_PAR_T1_LSB_REGISTER, &register_read_data[1U], 1U, 500);

	bme680_param_holder.par_t1 = (register_read_data[0U] << 8U) | (register_read_data[1U]);

	memset(register_read_data, 0x00U, 2U);


	status = drv_bme680_read_register(BME680_TEMP_CALLI_FACTOR_PAR_T2_MSB_REGISTER, &register_read_data[0U], 1U, 500);

	status = drv_bme680_read_register(BME680_TEMP_CALLI_FACTOR_PAR_T2_LSB_REGISTER, &register_read_data[1U], 1U, 500);

	bme680_param_holder.par_t2 = (register_read_data[0U] << 8U) | (register_read_data[1]);

	memset(register_read_data, 0x00U, 2U);


	status = drv_bme680_read_register(BME680_TEMP_CALLI_FACTOR_PAR_T3_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_t3 = register_read_data[0U];

	memset(register_read_data, 0x00U, 2U);

	return status;
}

static HAL_StatusTypeDef drv_bme680_read_temp_adc(uint32_t* temp_adc)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	*temp_adc = (uint32_t)(((uint32_t)bme680_param_holder.all_adc_reg_data[5] * 4096) | ((uint32_t)bme680_param_holder.all_adc_reg_data[6] * 16) | ((uint32_t)bme680_param_holder.all_adc_reg_data[7] / 16));



//	uint8_t shift = (bme680_param_holder.temp_oversampling_settings - 1U);
//
//	*temp_adc = ( (bme680_param_holder.all_adc_reg_data[5] << (shift + 8U)) | (bme680_param_holder.all_adc_reg_data[6] << shift) |
//			      (bme680_param_holder.all_adc_reg_data[7] >> (8U - shift)) );

	if(*temp_adc != 0x80000U)
	{
		status = HAL_OK;
	}

	return status;
}

static HAL_StatusTypeDef drv_bme680_set_iir_filter_config(bme860_iir_filter_settings_t bme860_iir_filter_settings)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	status = drv_bme680_write_register(BME680_IIR_FLITER_CONTROL_REGISTER, &bme860_iir_filter_settings, 1U, 100U);

	return status;
}


HAL_StatusTypeDef drv_bme680_soft_reset()
{
	HAL_StatusTypeDef status = HAL_ERROR;

	uint8_t send_buffer = 0xB6U;

	status = drv_bme680_write_register(BME680_SOFT_RESET_REGISTER, &send_buffer, 1U, 100U);

	drv_bme680_delay_us(1000);

	return status;
}



static HAL_StatusTypeDef drv_bme680_get_press_calli_factors()
{
	HAL_StatusTypeDef status = HAL_ERROR;

	uint8_t register_read_data[2U] = {0U};

	/* Reading par_p1 */

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P1_MSB_REGISTER, &register_read_data[0U], 1U, 500);

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P1_LSB_REGISTER, &register_read_data[1U], 1U, 500);

	bme680_param_holder.par_p1 = (register_read_data[0U] << 8U) | (register_read_data[1]);

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_p2 */

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P2_MSB_REGISTER, &register_read_data[0U], 1U, 500);

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P2_LSB_REGISTER, &register_read_data[1U], 1U, 500);

	bme680_param_holder.par_p2 = (register_read_data[0U] << 8U) | (register_read_data[1]);

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_p3 */

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P3_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_p3 = register_read_data[0U];

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_p4 */

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P4_MSB_REGISTER, &register_read_data[0U], 1U, 500);

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P4_LSB_REGISTER, &register_read_data[1U], 1U, 500);

	bme680_param_holder.par_p4 = (register_read_data[0U] << 8U) | (register_read_data[1]);

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_p5 */

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P5_MSB_REGISTER, &register_read_data[0U], 1U, 500);

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P5_LSB_REGISTER, &register_read_data[1U], 1U, 500);

	bme680_param_holder.par_p5 = (register_read_data[0U] << 8U) | (register_read_data[1]);

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_p6 */

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P6_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_p6 = register_read_data[0U];

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_p7 */

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P7_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_p7 = register_read_data[0U];

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_p8 */

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P8_MSB_REGISTER, &register_read_data[0U], 1U, 500);

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P8_LSB_REGISTER, &register_read_data[1U], 1U, 500);

	bme680_param_holder.par_p8 = (register_read_data[0U] << 8U) | (register_read_data[1]);

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_p9 */

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P9_MSB_REGISTER, &register_read_data[0U], 1U, 500);

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P9_LSB_REGISTER, &register_read_data[1U], 1U, 500);

	bme680_param_holder.par_p9 = (register_read_data[0U] << 8U) | (register_read_data[1]);

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_p10 */

	status = drv_bme680_read_register(BME680_PRESS_CALLI_FACTOR_PAR_P10_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_p10 = register_read_data[0U];

	return status;

}

static HAL_StatusTypeDef drv_bme680_read_press_adc(uint32_t* press_adc)
{
	HAL_StatusTypeDef status = HAL_ERROR;


	*press_adc = (uint32_t)(((uint32_t)bme680_param_holder.all_adc_reg_data[2] * 4096) | ((uint32_t)bme680_param_holder.all_adc_reg_data[3] * 16) | ((uint32_t)bme680_param_holder.all_adc_reg_data[4] / 16));

	if(*press_adc != 0x80000U)
	{
		status = HAL_OK;
	}

	return status;
}



static HAL_StatusTypeDef drv_bme680_get_humid_calli_factors()
{
	HAL_StatusTypeDef status = HAL_ERROR;

	uint8_t register_read_data[2U] = {0U};

	uint8_t read_buff = 0;

	/* Reading par_h1_h2 lsb */

	status = drv_bme680_read_register(BME680_HUMID_CALLI_FACTOR_PAR_H1_H2_LSB_REGISTER, &read_buff, 1U, 500);

	/* Reading par_h1_msb */

	status = drv_bme680_read_register(BME680_HUMID_CALLI_FACTOR_PAR_H1_MSB_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_h1 = (register_read_data[0U] << 4U) | (read_buff & 0x0F);

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_h2_msb */

	status = drv_bme680_read_register(BME680_HUMID_CALLI_FACTOR_PAR_H2_MSB_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_h2 = (register_read_data[0U] << 4U) | (((read_buff & 0xF0)>> 4U));

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_h3 */

	status = drv_bme680_read_register(BME680_HUMID_CALLI_FACTOR_PAR_H3_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_h3 = register_read_data[0U];

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_h4 */

	status = drv_bme680_read_register(BME680_HUMID_CALLI_FACTOR_PAR_H4_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_h4 = register_read_data[0U];

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_h5 */

	status = drv_bme680_read_register(BME680_HUMID_CALLI_FACTOR_PAR_H5_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_h5 = register_read_data[0U];

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_h6 */

	status = drv_bme680_read_register(BME680_HUMID_CALLI_FACTOR_PAR_H6_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_h6 = register_read_data[0U];

	memset(register_read_data, 0x00U, 2U);

	/* Reading par_h7 */

	status = drv_bme680_read_register(BME680_HUMID_CALLI_FACTOR_PAR_H7_REGISTER, &register_read_data[0U], 1U, 500);

	bme680_param_holder.par_h7 = register_read_data[0U];

	memset(register_read_data, 0x00U, 2U);

	return status;

}


static HAL_StatusTypeDef drv_bme680_read_humid_adc(uint16_t* humid_adc)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	*humid_adc = (uint16_t)(((uint32_t)bme680_param_holder.all_adc_reg_data[8] * 256) | (uint32_t)bme680_param_holder.all_adc_reg_data[9]);

	if(*humid_adc != 0x8000U)
	{
		status = HAL_OK;
	}

	return status;}


static HAL_StatusTypeDef drv_bme680_get_heater_and_gas_calli_factors()
{
	HAL_StatusTypeDef status = HAL_ERROR;

		uint8_t register_read_data[2U] = {0U};

		/* Reading par_g1 */

		status = drv_bme680_read_register(BME680_HEATER_CALLI_FACTOR_PAR_G1_REGISTER, &register_read_data[0U], 1U, 500);

		bme680_param_holder.par_g1 = register_read_data[0U];

		memset(register_read_data, 0x00U, 2U);

		/* Reading par_g2 */

		status = drv_bme680_read_register(BME680_HEATER_CALLI_FACTOR_PAR_G2_MSB_REGISTER, &register_read_data[0U], 1U, 500);

		status = drv_bme680_read_register(BME680_HEATER_CALLI_FACTOR_PAR_G2_LSB_REGISTER, &register_read_data[1U], 1U, 500);

		bme680_param_holder.par_g2 = (register_read_data[0U] << 8U) | (register_read_data[1]);

		memset(register_read_data, 0x00U, 2U);

		/* Reading par_g3 */

		status = drv_bme680_read_register(BME680_HEATER_CALLI_FACTOR_PAR_G3_REGISTER, &register_read_data[0U], 1U, 500);

		bme680_param_holder.par_g3 = register_read_data[0U];

		memset(register_read_data, 0x00U, 2U);

		/* Reading res_heat_range <5:4> */

		status = drv_bme680_read_register(BME680_HEATER_RES_HEAT_RANGE_REGISTER, &register_read_data[0U], 1U, 500);

		bme680_param_holder.res_heat_range = ((register_read_data[0U] >> 4) && 0x03U);

		memset(register_read_data, 0x00U, 2U);

		/* Reading res_heat_val */

		status = drv_bme680_read_register(BME680_HEATER_RES_HEAT_VAL_REGISTER, &register_read_data[0U], 1U, 500);

		bme680_param_holder.res_heat_val = register_read_data[0U];

		memset(register_read_data, 0x00U, 2U);

		/* Reading gas_range <3:0>*/
		status = drv_bme680_read_register(BME680_GAS_R_LSB_REGISTER, &register_read_data[0U], 1U, 500);

		bme680_param_holder.gas_range = (register_read_data[0U] & 0x0f);

		memset(register_read_data, 0x00U, 2U);

		/* Reading range_switch_error */
		status = drv_bme680_read_register(BME680_GAS_RANGE_SWITCHING_ERROR_REGISTER, &register_read_data[0U], 1U, 500);

		bme680_param_holder.range_switching_error = register_read_data[0U];

		memset(register_read_data, 0x00U, 2U);

		return status;
}

//static HAL_StatusTypeDef drv_bme680_tpgh_cycles_for_heater_warm_up()
//{
//	HAL_StatusTypeDef status = HAL_ERROR;
//
//	uint8_t no_of_read =0;
//
//	for(uint8_t i = 0; i < no_of_read ; i++)
//	{
//		status = drv_bme680_read_all_data();
//	}
//
//}


static HAL_StatusTypeDef drv_bme680_set_heater_resistance_profile(uint16_t* temp_for_resistance, uint8_t no_of_profile)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	uint8_t heater_resistance_reg = BME680_GAS_SENSOR_TARGET_HEATER_RESIST_0_REGISTER;

	if(no_of_profile > 10U)
	{
		/* 10 are maximum allowed*/
		no_of_profile = 10U;
	}

	for(uint8_t i = 0 ; i < no_of_profile ; i++)
	{
		uint8_t calculated_val = 0;

		calculated_val = calc_res_heat(temp_for_resistance[i]);

		status = drv_bme680_write_register(heater_resistance_reg, &calculated_val, 1, 200);

		if(status == HAL_OK)
		{
			/*TODO:  Success LOG*/
		}
		else
		{
			/*TODO:  Fail LOG*/
		}

		heater_resistance_reg++;
	}

	return status;
}


static HAL_StatusTypeDef drv_bme680_set_gas_wait_profile(uint8_t* gas_wait, uint8_t no_of_profile)
{

	HAL_StatusTypeDef status = HAL_ERROR;

	uint8_t gas_wait_reg = BME680_GAS_SENSOR_WAIT_TIME_0_REGISTER;

	if(no_of_profile > 10U)
	{
		/* 10 are maximum allowed*/
		no_of_profile = 10U;
	}

	for(uint8_t i = 0 ; i < no_of_profile ; i++)
	{
		uint8_t calculated_val = 0;

		calculated_val = calc_gas_wait(gas_wait[i]);

		status = drv_bme680_write_register(gas_wait_reg, &calculated_val, 1, 200);

		if(status == HAL_OK)
		{
			/*TODO:  Success LOG*/
		}
		else
		{
			/*TODO:  Fail LOG*/
		}

		gas_wait_reg++;
	}

	return status;
}

static float drv_bme380_int_gas_resistance_algo(uint16_t gas_res_adc)
{
    float calc_gas_res;
    float var1;
    float var2;
    float var3;
    float gas_res_f = gas_res_adc;
    float gas_range_f = (1U << bme680_param_holder.gas_range); /*lint !e790 / Suspicious truncation, integral to float */
    const float lookup_k1_range[16] = {
        0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, -0.8f, 0.0f, 0.0f, -0.2f, -0.5f, 0.0f, -1.0f, 0.0f, 0.0f
    };
    const float lookup_k2_range[16] = {
        0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.7f, 0.0f, -0.8f, -0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f
    };

    var1 = (1340.0f + (5.0f * bme680_param_holder.range_switching_error));
    var2 = (var1) * (1.0f + lookup_k1_range[bme680_param_holder.gas_range] / 100.0f);
    var3 = 1.0f + (lookup_k2_range[bme680_param_holder.gas_range] / 100.0f);
    calc_gas_res = 1.0f / (float)(var3 * (0.000000125f) * gas_range_f * (((gas_res_f - 512.0f) / var2) + 1.0f));

    return calc_gas_res;
}




static HAL_StatusTypeDef drv_bme680_read_gas_adc(uint16_t* gas_adc)
{
	HAL_StatusTypeDef status = HAL_ERROR;

	*gas_adc = (uint16_t)((uint32_t)bme680_param_holder.all_adc_reg_data[13U] * 4U | (((uint32_t)bme680_param_holder.all_adc_reg_data[14]) / 64));

	bme680_param_holder.gas_range = (bme680_param_holder.all_adc_reg_data[14U] & 0x0f);

	if(*gas_adc != 0U)
	{
		status = HAL_OK;
	}

	return status;
}
static uint8_t calc_res_heat(uint16_t temp)
{
    float var1;
    float var2;
    float var3;
    float var4;
    float var5;
    uint8_t res_heat;

    if (temp > 400) /* Cap temperature */
    {
        temp = 400;
    }

    var1 = (((float)bme680_param_holder.par_g1 / (16.0f)) + 49.0f);
    var2 = ((((float)bme680_param_holder.par_g2 / (32768.0f)) * (0.0005f)) + 0.00235f);
    var3 = ((float)bme680_param_holder.par_g3 / (1024.0f));
    var4 = (var1 * (1.0f + (var2 * (float)temp)));
    var5 = (var4 + (var3 * (float)bme680_param_holder.amb_temp));
    res_heat =
        (uint8_t)(3.4f *
                  ((var5 * (4 / (4 + (float)bme680_param_holder.res_heat_range)) *
                    (1 / (1 + ((float)bme680_param_holder.res_heat_val * 0.002f)))) -
                   25));

    return res_heat;
}

static float drv_bme380_int_temp_algo(uint32_t temp_adc)
{
	    float var1;
	    float var2;
	    float calc_temp;

	    /* calculate var1 data */
	    var1 = ((((float)temp_adc / 16384.0f) - ((float)bme680_param_holder.par_t1 / 1024.0f)) * ((float)bme680_param_holder.par_t2));

	    /* calculate var2 data */
	    var2 =
	        (((((float)temp_adc / 131072.0f) - ((float)bme680_param_holder.par_t1 / 8192.0f)) *
	          (((float)temp_adc / 131072.0f) - ((float)bme680_param_holder.par_t1 / 8192.0f))) * ((float)bme680_param_holder.par_t3 * 16.0f));

	    /* t_fine value*/
	    bme680_param_holder.t_fine = (var1 + var2);

	    /* compensated temperature data*/
	    calc_temp = ((bme680_param_holder.t_fine) / 5120.0f);

	    return calc_temp;


}

static float drv_bme380_int_press_algo(uint32_t press_adc)
{
    float var1;
    float var2;
    float var3;
    float calc_pres;

    var1 = (((float)bme680_param_holder.t_fine / 2.0f) - 64000.0f);
    var2 = var1 * var1 * (((float)bme680_param_holder.par_p6) / (131072.0f));
    var2 = var2 + (var1 * ((float)bme680_param_holder.par_p5) * 2.0f);
    var2 = (var2 / 4.0f) + (((float)bme680_param_holder.par_p4) * 65536.0f);
    var1 = (((((float)bme680_param_holder.par_p3 * var1 * var1) / 16384.0f) + ((float)bme680_param_holder.par_p2 * var1)) / 524288.0f);
    var1 = ((1.0f + (var1 / 32768.0f)) * ((float)bme680_param_holder.par_p1));
    calc_pres = (1048576.0f - ((float)press_adc));

    /* Avoid exception caused by division by zero */
    if ((int)var1 != 0)
    {
        calc_pres = (((calc_pres - (var2 / 4096.0f)) * 6250.0f) / var1);
        var1 = (((float)bme680_param_holder.par_p9) * calc_pres * calc_pres) / 2147483648.0f;
        var2 = calc_pres * (((float)bme680_param_holder.par_p8) / 32768.0f);
        var3 = ((calc_pres / 256.0f) * (calc_pres / 256.0f) * (calc_pres / 256.0f) * (bme680_param_holder.par_p10 / 131072.0f));
        calc_pres = (calc_pres + (var1 + var2 + var3 + ((float)bme680_param_holder.par_p7 * 128.0f)) / 16.0f);
    }
    else
    {
        calc_pres = 0;
    }

    return calc_pres;

}

static float drv_bme380_int_humid_algo(uint16_t humid_adc)
{
    float calc_hum;
    float var1;
    float var2;
    float var3;
    float var4;
    float temp_comp;

    /* compensated temperature data*/
    temp_comp = ((bme680_param_holder.t_fine) / 5120.0f);
    var1 = (float)((float)humid_adc) -
           (((float)bme680_param_holder.par_h1 * 16.0f) + (((float)bme680_param_holder.par_h3 / 2.0f) * temp_comp));
    var2 = var1 *
           ((float)(((float)bme680_param_holder.par_h2 / 262144.0f) *
                    (1.0f + (((float)bme680_param_holder.par_h4 / 16384.0f) * temp_comp) +
                     (((float)bme680_param_holder.par_h5 / 1048576.0f) * temp_comp * temp_comp))));
    var3 = (float)bme680_param_holder.par_h6 / 16384.0f;
    var4 = (float)bme680_param_holder.par_h7 / 2097152.0f;
    calc_hum = var2 + ((var3 + (var4 * temp_comp)) * var2 * var2);
    if (calc_hum > 100.0f)
    {
        calc_hum = 100.0f;
    }
    else if (calc_hum < 0.0f)
    {
        calc_hum = 0.0f;
    }

    return calc_hum;

}


static uint8_t calc_gas_wait(uint16_t dur)
{
    uint8_t factor = 0;
    uint8_t durval;

    if (dur >= 0xfc0)
    {
        durval = 0xff; /* Max duration*/
    }
    else
    {
        while (dur > 0x3F)
        {
            dur = dur / 4;
            factor += 1;
        }

        durval = (uint8_t)(dur + (factor * 64));
    }

    return durval;
}


static HAL_StatusTypeDef drv_bme680_measuremen_complete_check()
{

	HAL_StatusTypeDef status = HAL_ERROR;

	uint8_t read_retry		= 5U; /* This should be congif.h file it is here for testing purposes */
	uint8_t i	= 0;
	uint8_t meas_status_reg = 0U;
	uint8_t gas_r_lsb_reg	= 0U;

	do
	{
		status = drv_bme680_read_register(BME680_MEASUREMENT_STATUS_REGISTER, &meas_status_reg, 1, 100);

		bme680_param_holder.new_data_0_flag = (meas_status_reg >> 7U);
		bme680_param_holder.gas_measuring_flag = (meas_status_reg >> 6U);
		bme680_param_holder.measuring_flag = (meas_status_reg >> 5U);
		i++;

	}while( (bme680_param_holder.new_data_0_flag == 0U) && (i < read_retry) );

	status = drv_bme680_read_register(BME680_GAS_R_LSB_REGISTER, &gas_r_lsb_reg, 1, 100);

	if((status == HAL_OK) && (bme680_param_holder.gas_measuring_flag == 0U) && (bme680_param_holder.measuring_flag == 0U))
	{
		bme680_param_holder.gas_valid_r_flag = (gas_r_lsb_reg >> 5U);
		bme680_param_holder.heat_stab_r_flag = (gas_r_lsb_reg >> 4U);

		if((bme680_param_holder.gas_valid_r_flag == 0) | (bme680_param_holder.heat_stab_r_flag == 0))
		{
			status = HAL_ERROR;
		}
	}

	return status;

}


static void drv_bme680_delay_us(uint32_t delay_us)
{
	HAL_Delay(delay_us/1000U);
}

static void drv_bme680_get_gas_reference()
{
	// Now run the sensor for a burn-in period, then use combination of relative humidity and gas resistance to estimate indoor air quality as a percentage.
    bme680_output_t data;

	int readings = 10;

	for (int i = 1; i <= readings; i++)
	{
		// read gas for 10 x 0.150mS = 1.5secs
		drv_bme680_read_all_data(&data) ;

		gas_reference += data.heater_resistance;
	}
	gas_reference = gas_reference / readings;

}



//Calculate humidity contribution to IAQ index
static int8_t drv_bme680_get_humidity_score(float humid)
{
	if (humid >= 38 && humid  <= 42) // Humidity +/-5% around optimum
		{
			humidity_score = 0.25 * 100;
		}
	else
	{ // Humidity is sub-optimal
		if (humid  < 38)
		{
			humidity_score = 0.25 / hum_reference * humid  * 100;
		}
		else
		{
			humidity_score = ((-0.25 / (100 - hum_reference) * humid ) + 0.416666) * 100;
		}
	}

	return humidity_score;
}

//Calculate gas contribution to IAQ index
static int8_t drv_bme680_get_gas_score()
{
	gas_score = (0.75 / (gas_upper_limit - gas_lower_limit) * gas_reference
			- (gas_lower_limit * (0.75 / (gas_upper_limit - gas_lower_limit))))
			* 100.00;
	if (gas_score > 75)
		gas_score = 75; // Sometimes gas readings can go outside of expected scale maximum
	if (gas_score < 0)
		gas_score = 0; // Sometimes gas readings can go outside of expected scale minimum

	return gas_score;
}

float drv_bme680_iaq(bme680_output_t* data)
{
	float air_quality_score = (100 - (drv_bme680_get_humidity_score(data->humid) + drv_bme680_get_gas_score())) * 5;

	// If 5 measurements passed, recalculate the gas reference.
	if ((getgasreference_count++) % 5 == 0)
		drv_bme680_get_gas_reference();
	return air_quality_score;
}
